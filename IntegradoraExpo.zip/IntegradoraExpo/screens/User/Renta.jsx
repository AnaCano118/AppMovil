import { Text } from "@rneui/base";
import { StyleSheet, View } from "react-native";

Renta = () => {
    return(
        <View style={styles.container}>
            <Text>Aca va el mapa</Text>
        </View>
    )
}

export default Renta;

const styles = StyleSheet.create ({
    container:{
        flex:1,
        backgroundColor:'Black',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom:20,
        marginTop:35
    },
    text:{
        fontSize:15,
        margin:5,
        fontFamily:'Arial'
    }
})