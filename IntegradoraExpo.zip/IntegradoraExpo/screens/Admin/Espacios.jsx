import { Text } from "@rneui/base";
import { View } from "react-native";

Spaces = ()=>{
 return(
    <View>
        <Text>Espacios</Text>
    </View>
 )
}

export default Spaces;