import { Card, Image, Text } from "@rneui/base";
import { StyleSheet, View } from "react-native";

Maps = ()=>{
    return(
        <View style={{marginTop:35}}>
            <View style={styles.header}>
                <Text style={styles.titulo}>Croquis</Text>
            </View>
            <Card>
                    <Card.Title>Evento: Harry pother</Card.Title>
                    <Card.Divider/>
                    <View style={styles.contenedorPrincipal}>
                    <View style={styles.contenedorImagen}>
                    <Image style={styles.imagen} source={require('../../images/casasH.jpg')}/>
                    </View>
                    <View style={styles.contenedorTexto}>
                    <Text>Descripción: Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore</Text>
                    </View>
                    </View>
                    <Button
                   buttonStyle={{margin:5, borderRadius:20}}
                    title={'Editar'}
                    color={'#129E9E'}
                    />
                    <Button
                    buttonStyle={{margin:5, borderRadius:20}}
                    title={'Eliminar'}
                    color={'#129E9E'}
                    />
                </Card>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#129E9E',
    },
    header: {
        backgroundColor: '#00C89F',
        padding: 25,
        alignItems: 'center',
        },
        titulo: {
            fontFamily:'Arial',
            fontWeight: 'bold',
            fontSize:35,
          },
})

export default Maps;